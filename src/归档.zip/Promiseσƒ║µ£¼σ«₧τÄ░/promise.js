const PENDING = 'PENDING';
const FULFILLED = 'FULFILLED';
const REJECTED = 'REJECTED';

class Promise {
  constructor(executor) {
    this.status = PENDING;
    this.value = null; // 储存成功的值
    this.reason = null; // 储存失败的值

    // 处理异步情况：Promise调用then的时候，状态可能是penging，需要将成功的和失败的回调存起来
    this.onResolveCallbacks = []; // 存放成功回调，调用reslove时，触发onResolveCallbacks执行
    this.onRejectedCallbacks = []; // 存放失败回调，调用rejected时，触发onRejectedCallbacks执行

    // 只有状态为pending时，才可以更改状态，并且改变成功或者失败的原因
    const resolve = (value) => {
        if(this.status === PENDING) {
          this.status = FULFILLED;
          this.value = value;
          // 调用成功的回调
          executeCallback(this.onResolveCallbacks)
        }
    };
    const reject = (reason) => {
      if(this.status === PENDING) {
        this.status = REJECTED;
        this.reason = reason;
        // 调用失败的回调
        executeCallback(this.onRejectedCallbacks)
      }
    };
    /** 
     * 调用executor, 会传入resolve和reject参数
     * 如果executor()报错，则在try中抛出异常
     * */
    try {
      executor(resolve, reject);
    } catch(e){
      reject(e);
    }
   }
   
  /**
   * @description: promise的then方法
   * @param {*} onFulfilled 如果成功时的回调
   * @param {*} onRejected 如果失败时的回调
   * @author: huchao
   */
  then(onFulfilled, onRejected = () => {}) { 
    // 成功时
    if (this.status === FULFILLED ) {
        onFulfilled(this.value)
    }
    // 失败时
    if (this.status === REJECTED ) {
        onRejected(this.reason)
    } 
    // pengding中
    if (this.status === PENDING) {
       this.onResolveCallbacks.push(() => {
          // DDDD
          onFulfilled(this.value)  
       });
       this.onRejectedCallbacks.push(() => {
          // DDDD
          onRejected(this.reason)  
     });
    }
  }
}

/**
 * @description: 依次执行回调函数
 * @param {*} list
 * @author: huchao
 */
const executeCallback = (list) => {
  list.forEach(callback => callback());
};

module.exports = Promise;