const Promise = require('./promise');
const test = new Promise((resolve, reject) => {
  // reject('江思敏是一只猪')
  setTimeout(() => {
    resolve('江思敏是一只猪')
  }, 1000);
});
test.then(data => {
  console.log(data, '成功了1')
}, (err) => {
  console.log(err, '失败了1')
})

test.then(data => {
  console.log(data, '成功了2')
}, (err) => {
  console.log(err, '失败了2')
}) 