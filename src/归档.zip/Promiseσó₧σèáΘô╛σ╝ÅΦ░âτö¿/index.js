// import { Promise } from "./promise";
// const Promise = require('./promise基本实现');
const Promise = require('./promise')

const fs = require('fs'); // node文件系统模块
const path = require('path'); // node 路径模块
// const { promisify } = require('util');

/**
 * @description: 实现一个promisify方法（实际是一个高阶函数）
 * @param {*} fn 等价于 fs.readFile
 * @return {*} 返回一个函数 <=> 最后调用的readFile函数
 * @author: huchao
 */
function promisify(fn) {
  // reutrn出去的方法就是readFile
  return function(...args){
    return new Promise((resolve, reject) => {
      // 添加了一个回调函数
      const callback = (err, data) => {
          if(err) return reject(err);
          resolve(data)
      };
      // fn: 传入进来的 fs.readFile 方法
      fn(...args, callback);
    }) 
  }
}
const readFile = promisify(fs.readFile);

readFile(path.resolve(__dirname, 'test1.txt'), 'utf-8').then((data, err) => {
  console.log(data)
});